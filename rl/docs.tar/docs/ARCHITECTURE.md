# 网络架构方向

本文回答两个问题：**观测/动作怎么定义**、**策略网络怎么搭**。结论先给：

| 决策点 | 结论 | 理由 |
|---|---|---|
| 算法 | **PPO（on-policy）** | 环境是物理仿真（非平稳、有噪声），PPO 对超参不敏感、易调稳；且 godot_rl 生态成熟 |
| 多车策略 | **参数共享的单一策略**（single shared policy） | 同质 agent + 自车视角观测 → 等价于"单智能体 + 向量化环境"，样本效率最高 |
| 观测编码 | **分塔（split-tower）MLP**，而非单一 MLP | 射线占 62% 维度，单 MLP 会被它主导，忽略导航目标 |
| 主体网络 | `[256, 256]` + Tanh/ReLU | 615 维观测 + 3 维动作，容量足够，再大只是过拟合 |
| 记忆 | 默认**无 LSTM**；对手博弈阶段可加 | 物理状态本身近似马尔可夫，LSTM 先上会拖慢收敛 |
| 奖励归一化 | **关闭 VecNormalize** | 观测已在 GDScript 归一化，奖励尺度已人工设计 |

---

## 1. 观测（Observation）

### 1.1 现状：615 维扁平向量

`AITaxiController.get_obs()` 按固定顺序拼接三段：

```
[0:8]     自车状态          8 维
[8:392]   射线传感器      384 维   ← 8 个 RayCastSensor3D
[392:615] 位置传感器      223 维   ← PassengerPositionSensor3D + RivalPositionSensor
```

**自车状态（8 维）**

| idx | 含义 | 归一化 |
|---|---|---|
| 0 | `n_steps / reset_after` | 回合进度 |
| 1 | 前向车速 | `/ max_speed_mps` |
| 2 | 横向车速 | `/ max_speed_mps` |
| 3 | 横摆角速度 | `× 0.5` |
| 4 | 当前转向角 / 最大转向角 | 比值 |
| 5 | 发动机转速 / 最大转速 | 比值 |
| 6 | 挡位 / 最大挡位 | 比值 |
| 7 | 是否着地 | 0/1 |

**射线（384 维）**：前/后/左/右 × 远/近 = 8 个传感器，
每个输出 `n_rays_width × n_rays_height × (1 + class_sensor)`：

| 传感器 | 网格 | class_sensor | 维度 |
|---|---|---|---|
| Front/FarSightFront | 6×3 | 是 | 36 |
| Front/NearSightFront | 10×3 | 是 | 60 |
| Back/FarSightBack | 6×3 | 是 | 36 |
| Back/NearSightBack | 10×3 | 是 | 60 |
| Left/FarSightLeft | 6×3 | 是 | 36 |
| Left/NearSightLeft | 10×3 | 是 | 60 |
| Right/FarSightRight | 6×3 | 是 | 36 |
| Right/NearSightRight | 10×3 | 是 | 60 |
| **合计** | | | **384** |

每根射线输出两位：`距离`（未命中为 0.0，命中越近越接近 1.0）和 `类别`（0/1）。

**位置（223 维）**：`PassengerPositionSensor3D`（当前目标相对位置，`include_xyz=true` → 3 维）
+ `RivalPositionSensor`（`max_opponents_obs × 4` 维，默认 6×4=24）。
> 223 这个数字取决于场景里实际挂了几个位置传感器，**请以运行时打印的
> `observation_space` 为准**（训练启动时 `rl/train.py` 会打印）。

### 1.2 观测的三处缺口（建议补齐）

| 缺口 | 影响 | 建议 |
|---|---|---|
| **没有"自车朝向 vs 目标方向"的显式夹角** | 位置传感器给的是车体坐标系下的相对 x/z，策略要靠 MLP 自己反推"该往哪打方向盘"，学习曲线会明显变慢 | 加一个 2 维观测：`[cos(θ), sin(θ)]`，θ = 目标方位角 − 车头朝向 |
| **载客时看不到"乘客目的地相对位置"以外的任务状态** | 无法区分"空车找客"和"载客送客"两种子任务 | 加 2 维：`[has_passenger, 是否已接客但未送达]` |
| **对手只有相对位置，没有相对速度/朝向** | 竞争阶段难以预判对手是否在冲同一个乘客 | 每个对手加 2 维：`[相对前向速度, 相对朝向]`（`RivalPositionSensor` 里补） |

> 补观测**必须一次性补齐并固定下来**：godot_rl 的观测空间在握手时确定，
> 训练中途改维度会让 SB3 直接报 shape 错误。所以请在第一轮正式训练前定稿。

### 1.3 观测分组（供分塔编码使用）

`rl/feature_extractors.py` 的 `CombinedExtractor` 按语义切分：

```
self     8    → Linear(8,128)   → LayerNorm → ReLU → Linear(128,128) → ReLU
raycast  384  → Linear(384,128) → LayerNorm → ReLU → Linear(128,128) → ReLU
position 223  → Linear(223,128) → LayerNorm → ReLU → Linear(128,128) → ReLU
                                  ↓ concat
                              384 维特征 → PPO 的 mlp_extractor [256,256]
```

**为什么分塔**：
- 射线 384 维里绝大多数是 0.0（未命中），信息密度低；位置传感器 223 维才是"该去哪"的决策依据。单 MLP 的首层会把梯度按维度比例分配给射线，导致策略偏向避障。
- 分塔后每组先压到同维（128），再拼接，等价于给每组一个独立的"注意力预算"。
- `LayerNorm` 稳定稀疏输入的方差（射线 0.0 扎堆）。

**为什么不用 CNN 处理射线**：射线是 6×3 / 10×3 的小网格，卷积核还没学出东西就先过拟合了；线性层 + 隐藏层足够。若后续把射线升级成 RGB 相机（`RGBCameraSensor3D`），那才需要给图像分支加 CNN（`CnnPolicy` / 自定义提取器里挂 `NatureCNN`）。

---

## 2. 动作（Action）

### 2.1 现状：3 维连续

```gdscript
func get_action_space() -> Dictionary:
    return {
        "throttle": {"size": 1, "action_type": "continuous"},
        "steering": {"size": 1, "action_type": "continuous"},
        "brake":    {"size": 1, "action_type": "continuous"},
    }
```

godot_rl 的 `ActionSpaceProcessor(convert_action_space=True)` 会把这三个键
**压成一个 `Box(3)`**（顺序 = 字典键顺序：throttle, steering, brake），
SB3 训练时看到的是 `Box(-1,1,(3,))`，发送前再拆回字典。

### 2.2 建议：改为 2 维（throttle 带符号 + steering）

现在的 `throttle ∈ [-1,1]` 已经在 `set_action()` 里被拆成 `throttle_forward/throttle_back`，
而 `brake ∈ [0,1]` 与"反向油门"语义重叠——车辆 `mmt_sedan.gd` 的 `auto_reverse` 逻辑
本来就会把反向油门当刹车。让策略同时学"踩多少刹车"和"反向油门"是**冗余动作维度**，
会让探索效率下降。

**推荐动作空间（2 维）**：

| 维度 | 范围 | 语义 |
|---|---|---|
| `throttle` | [-1, 1] | >0 前进油门，<0 刹车/倒车（交给 `auto_reverse` 处理） |
| `steering` | [-1, 1] | 转向 |

若你希望保留显式刹车（更可控、便于做"必须停稳才能接客"的任务），
那就保留 3 维，但建议把 `brake` 改成 **logit 形式**并用 `SquashingDist`，
或者在奖励里明确惩罚"同时踩油门和刹车"。

### 2.3 动作重复（action_repeat）

`Sync.action_repeat` 默认 **8**，即一个 RL 动作持续 8 个物理帧（60Hz 下约 133ms）。
这个值很关键：

- 太小（1~2）：策略要学高频控制，样本效率低，物理噪声大。
- 太大（≥16）：控制延迟明显，难以精细停靠（接客需要停稳）。
- **建议 4~8**，与 `AITaxiController.reset_after` 一起考虑：
  `reset_after=2000` 步 ≈ 2000 × 8 / 60 ≈ 266 秒游戏时间。

---

## 3. 策略网络

### 3.1 主体：PPO + MLP 分塔提取器

```python
# rl/feature_extractors.py 提供的 helper
kwargs = policy_kwargs(
    features="custom",          # "mlp" 可切回 SB3 默认 MLP 做对比
    net_arch=[256, 256],
    features_dim=128,
    raycast_dim=384,            # 改了场景里的射线配置就要改这里
)
model = PPO("MultiInputPolicy", env, policy_kwargs=kwargs, ...)
```

对应命令行：`python rl/train.py --features custom --raycast_dim 384`

**为什么是 `MultiInputPolicy`**：godot_rl 上报的观测空间是 `Dict{"obs": Box(n)}`。
即便只有一个键，也用 `MultiInputPolicy` 才能正确走字典分支（与官方示例一致）。
若把观测展平成纯 `Box`，可以换成 `MlpPolicy`——功能等价，但展平后自定义提取器
就没法按语义切分了，所以**不推荐**。

### 3.2 多车：参数共享单一策略

**这是本项目最重要的一条架构决策。**

三辆同型出租车，各自的观测都是"自车视角"，动作空间相同，奖励函数相同
（都由自己的 `RewardManager` 计算）→ 典型的**同质多智能体**。
标准做法是**参数共享**：所有 agent 共用一个策略网络，各自产生独立的
`(obs, action, reward, done)` 轨迹，全部塞进同一个 PPO 的 buffer。

在 godot_rl 里这件事是**自动发生**的：
- `Sync._get_agents()` 收集所有 `control_mode == TRAINING` 的 AIController；
- `_get_obs_from_agents()` 返回长度 = agent 数的数组；
- `StableBaselinesGodotEnv` 把它们当成 `num_envs` 个并行环境；
- SB3 的 PPO 看到的是 `batch_size = num_envs × n_steps` 的混合批次 → 天然参数共享。

**优点**：样本效率高（一辆车的经验直接帮到另一辆）、实现零成本、收敛快。
**缺点**：无法表达"公司 A 和公司 B 用不同策略"。

**如果之后要分策略**（比如让对手用不同的行为）：
- 用 `policy_name` 字段 + RLLib 多策略（`docs/TRAINING_MULTIPLE_POLICIES.md`）；
- 或者干脆训两个独立模型，在 Godot 侧用 ONNX 推理分别驱动。
- **但请不要在课程前三个阶段做这件事**——先确认共享策略能学到东西。

### 3.3 记忆（LSTM）什么时候上

默认 **不上**。理由：

1. 车辆物理状态（速度、横摆、转向）本身是马尔可夫的，观测里已经给了。
2. LSTM 会让 PPO 的 batch 构造复杂化（sequence 切分），收敛慢 2~5 倍。
3. 课程前两阶段是单车站任务，没有"必须记忆"的信息。

**什么时候该上**：
- 进入 S3 竞争阶段后，如果发现策略在"对手已经抢到某个乘客"后仍反复冲过去
  （说明它需要记住"那个乘客没戏了"），再考虑加 LSTM 或把该信息写进观测。
- 更便宜的替代方案：**把必要信息直接加进观测**（见 §1.2），比 LSTM 稳。

### 3.4 训练稳定性清单

| 现象 | 先查什么 |
|---|---|
| `ep_rew_mean` 不涨、熵迅速塌到 0 | `ent_coef` 调到 0.01；检查奖励是否全是负的（策略学会"早点结束回合"） |
| 车辆原地打转/不前进 | 低速惩罚 `grace_steps` 太小，或 `step_cost` 过大；先关掉 `isMovingRewardFunction` 跑一版 |
| 接客成功但送达失败 | `dropoff_radius` 太小 / `stop_speed_threshold` 太严；检查 `PassengerPositionSensor3D` 是否在载客时正确切到目的地 |
| 奖励震荡 | `n_epochs` 降到 5~8，`clip_range` 降到 0.1，`batch_size` 加大 |
| 学习曲线断崖式下跌 | 课程阶段切换时参数突变（尤其 `reset_after` 变小）。**推进阶段后至少跑完一个完整 rollout 再判断** |

---

## 4. 多智能体的三种路线（按投入排序）

| 路线 | 做法 | 投入 | 适用 |
|---|---|---|---|
| **A. 参数共享 PPO**（推荐起点） | 一个策略，所有车共享；观测是自车视角 | 低（godot_rl 原生支持） | 同质车队，竞争/协作都能学 |
| **B. 分策略 PPO/RLLib** | `policy_name` 区分公司，各自独立策略 | 中（要改配置 + 可能换 RLLib） | 想让不同公司有不同"性格" |
| **C. CTDE / MAPPO** | 训练时用全局 critic（能看到所有车状态），执行时只用局部观测 | 高（要写自定义 policy + 改协议传全局状态） | 需要强协作（车队协同接客），或竞争下需要收敛保证 |

**建议路径**：先 A 跑通 → 用 A 的结果做基线 → 只有当 A 在竞争阶段明显学不动
（比如长期卡在 50% 成功率且对手行为退化）时，才考虑 C。

原因：CTDE 的收益主要在**协作型**任务（需要信用分配）。本项目的竞争是零和的
"抢同一个乘客"，自车视角观测已经包含对手位置/是否载客，信息上够用，
A 路线的天花板不低。
