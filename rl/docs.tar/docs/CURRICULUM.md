# 课程学习方案：单车站 → 队友 → 竞争

> **本文是课程配置的唯一权威来源。** 课程阶段是**离线人工切换**的：
> 没有对应的 Python 模块，改完 Godot 侧配置后启动一次训练即可。

## 结论

**应该分阶段，但要拆成 5 个阶段，而不是 3 个。**

"单车站"这一步本身还包含两个难度量级完全不同的子问题（静止目标 vs 移动目标），
跳过它会让下一阶段的失败难以归因。

```
S0 单车站 · 静止乘客      ← 建立"靠近 + 停稳"的基本行为
S1 单车站 · 移动乘客      ← 加入目标运动
S2 双车站 · 同队协作      ← 引入参数共享的队友
S3 双公司 · 正面竞争      ← 引入对手抢客
S4 满编 · 混战            ← 目标场景长尾微调
```

**为什么必须先单车站**：

1. **奖励稀疏**。随机策略"恰好停稳在乘客 2 米内且速度 < 1.5 m/s"的概率极低。
   多辆车同时在跑，每辆车都要独立撞上这个概率，采样效率进一步下降。
2. **非平稳性**。队友/对手的行为随训练变化，PPO 面对移动靶，容易学出
   "跟着别人走"这种退化解。
3. **归因清晰**。单车站跑不出成绩，一定是驾驶/奖励的问题；多车站跑不出，
   可能是协作、观测、生成逻辑任何一个环节。先隔离变量。

---

## 阶段切换流程

```
1) 看下面表格，确定当前阶段该配什么
2) 在 Godot 编辑器里改配置
3) 启动训练（用 --experiment_name 区分阶段的 TensorBoard 目录）
4) 看 TensorBoard 的 task/dropoffs 和 task/success_rate，确认达标
5) 回到 2)，进入下一阶段
```

命令示例：

```bash
# S0
python rl/train.py --viz --experiment_name taxi_S0

# S1（沿用 S0 的权重继续训练）
python rl/train.py --viz --experiment_name taxi_S1 --resume_model_path rl/logs/taxi_S0.zip

# S4 并行无头训练
python rl/train.py --env_path build/AutoFollow.exe --n_parallel 8 --experiment_name taxi_S4
```

> Python 侧**不认识"阶段"这个概念**，它只是一个实验命名约定。
> 环境难度完全由 Godot 场景决定。

---

## 阶段参数表

### 要改在场景管理器上的（`AIParameter` 面板碰不到）

| 参数 | S0 | S1 | S2 | S3 | S4 | 位置 |
|---|---|---|---|---|---|---|
| `vehicles_per_faction` | 1 | 1 | 2 | 2 | 4 | `VehicleSpawnManager` |
| `faction_list` 公司数 | 1 | 1 | 1 | 2 | 2 | `VehicleSpawnManager` |
| `max_number`（乘客数） | 2 | 4 | 6 | 8 | 12 | `PassengerManager` |
| `moving_probability` | 0.0 | 0.5 | 0.5 | 0.5 | 0.5 | `PassengerManager` |

### 要改在 `AIParameter` 面板上的（键名 = 节点导出字段名）

| 参数 | S0 | S1 | S2 | S3 | S4 | 所在节点 |
|---|---|---|---|---|---|---|
| `reset_after` | 2000 | 2500 | 2500 | 3000 | 3500 | `AITaxiController` |
| `enable_success_terminal` | true | true | true | true | true | `AITaxiController` |
| `success_hold_frames` | 5 | 5 | 5 | 5 | 5 | `AITaxiController` |
| `reward_success` | 5.0 | 5.0 | 5.0 | 8.0 | 8.0 | `AITaxiController` |
| `reward_fail` | -6.0 | -6.0 | -6.0 | -6.0 | -6.0 | `AITaxiController` |
| `pickup_radius` | 2.5 | 2.0 | 2.0 | 2.0 | 2.0 | `AITaxiController` |
| `dropoff_radius` | 3.0 | 2.5 | 2.5 | 2.5 | 2.5 | `AITaxiController` |
| `stop_speed_threshold` | 2.0 | 1.5 | 1.5 | 1.5 | 1.5 | `AITaxiController` |
| `stolen_penalty` | 0.0 | 0.0 | 0.0 | 1.5 | 1.5 | `AITaxiController` |
| `shaping_scale` | 0.4 | 0.3 | 0.3 | 0.3 | 0.25 | `PickUpAndDropRewardFunction` |
| `reward_pickup` | 2.0 | 2.0 | 2.0 | 2.0 | 2.0 | `PickUpAndDropRewardFunction` |
| `reward_dropoff` | 5.0 | 6.0 | 6.0 | 8.0 | 8.0 | `PickUpAndDropRewardFunction` |
| `step_cost` | 0.01 | 0.01 | 0.012 | 0.015 | 0.015 | `PickUpAndDropRewardFunction` |
| `low_speed_threshold` | 0.5 | 0.5 | 0.5 | 0.5 | 0.5 | `isMovingRewardFunction` |
| `grace_steps` | 600 | 480 | 480 | 420 | 420 | `isMovingRewardFunction` |
| `penalty_per_step` | 0.001 | 0.001 | 0.001 | 0.001 | 0.001 | `isMovingRewardFunction` |
| `max_step_penalty` | 0.2 | 0.2 | 0.2 | 0.2 | 0.2 | `isMovingRewardFunction` |
| `max_opponents_obs` | 6 | 6 | 6 | 6 | 6 | `RivalPositionSensor` |
| `observe_same_company` | false | false | false | false | false | `RivalPositionSensor` |
| `max_distance` | 10.0 | 10.0 | 10.0 | 10.0 | 10.0 | 位置传感器 |

### 怎么把参数填进 Godot

**方式 A（推荐）**：用 `TrainScene.tscn` 里的 `AIParameter` 面板。

`AIParameterEntry` 的字段名与上表**完全同名**。填好后点面板上的
「一键同步到所有AI节点」，它会遍历场景里所有 AI 节点并写入同名字段。

> `AIParameterEntry.apply_to()` 只写目标节点上**确实存在**的字段，
> 所以奖励参数会自动落到 `PickUpAndDropRewardFunction`、传感器参数落到
> `RivalPositionSensor`——前提是这些节点在场景里存在。

**方式 B**：直接改 `vehicle/AI/mmt_ai_sedan.tscn` 里 `Rl` 子树的导出值。

---

## 几个关键取舍

### 1. `enable_success_terminal` 必须开

原代码里它是 `false`，且 `_end_episode()` 只在超时时调用 →
一个回合要跑满 `reset_after` 步才结束。

**后果**：`γ=0.99` 下，1000 步之后的奖励折扣到 `0.99^1000 ≈ 4e-5`，
策略**感受不到"送达"的价值**，只会学"怎么活到回合结束"。

**已修复**：`AITaxiController._physics_process()` 末尾新增成功终止分支，
送达后立即 `_end_episode(reward_success)`。注意 `reward_success` 是新增的
控制器导出字段——**不要用 `reward_dropoff`**，那个在奖励函数节点上，控制器里没有。

### 2. 低速惩罚与"停稳接客"天然冲突

`isMovingRewardFunction` 惩罚连续低速，但接客/送达**必须停稳**
（`stop_speed_threshold`）。默认 `grace_steps = 180` 步（3 秒）太短，
会把策略推向"永远不停车"，从而永远接不到客。

**处理**：
- S0~S2 把 `grace_steps` 设到 480~600 步（8~10 秒）。
- **更省事的调试手段**：S0 阶段先在 `RewardManager` 下**禁用**
  `isMovingRewardFunction`，确认策略能学会接客，再在 S1 加回来。

### 3. 观测长度在整条课程里必须固定

godot_rl 的观测空间在 `Sync` 握手时一次性确定，训练中改变会让 SB3 抛 shape 错误。

所以：**`max_opponents_obs` 从 S0 起就设成最终值（6）**，
课程只改"实际有几辆车"——那是运行时数据，不影响观测维度
（`RivalPositionSensor` 内部定长输出、不足补零）。

这样整条课程**无需重建环境**，模型权重可以跨阶段继续训练。

### 4. 阶段切换后必须"冷启动"观察

切换阶段会改变奖励权重和 `reset_after`，`ep_rew_mean` 会出现**一次性跳变**
（不是策略退化）。判断是否真的变差，要看切换后**至少一个完整 rollout**
（`n_steps × num_envs` 步）的 `task/success_rate` 和 `task/dropoffs`。

### 5. 跨阶段继续训练 vs 从零开始

| 情况 | 建议 |
|---|---|
| 只改奖励权重/回合长度（S0→S1） | `--resume_model_path` 继续训练，省时间 |
| 引入队友/对手（S2、S3） | 先试继续训练；若成功率长期不回升，再从零训 |
| 观测维度变了（改了 `max_opponents_obs` 或传感器） | **必须从零训**（权重形状不匹配） |

---

## 每个阶段结束前的人工检查清单

- [ ] `task/dropoffs` 在稳步上升（不是只有 `rollout/ep_rew_mean` 在涨）
- [ ] `task/success_rate` ≥ 该阶段目标（S0/S1 ≥ 60%，S2 ≥ 55%，S3 ≥ 50%）
- [ ] 录一段可视化，确认车辆**真的在开**，不是卡在墙里抖
- [ ] 载客后能正确前往目的地（不是接完客原地转圈）
- [ ] 若已进入 S2/S3：确认队友/对手的车也在动
- [ ] 环境没耗尽乘客（车辆数、乘客数符合阶段预期）
