# Godot 侧改动清单

Python 训练工程要跑通，Godot 侧需要这些改动。**已落地的改动**列在 §1，
**还需要你手工做的**列在 §2。

---

## 1. 已落地的改动

### 1.1 `vehicle/AI/AITaxiContorller.gd`

| 改动 | 说明 |
|---|---|
| 新增 `@export var reward_success: float = 5.0` | 成功终止（送达完成）时的终局奖励 |
| 新增 `_ev_picked_up` / `_ev_delivered` / `_ev_stolen` | 每帧复位的业务事件标志 |
| `get_info()` 扩展 | 新增 `is_carrying` / `picked_up` / `delivered` / `stolen` |
| `_do_dropoff()` | 置 `_ev_delivered = true` 且 `_success_frames = success_hold_frames` |
| `_do_pickup()` | 置 `_ev_picked_up = true` |
| `_on_target_lost()` | 被敌人抢客时置 `_ev_stolen = true` |
| `_physics_process()` | 新增成功终止分支：`enable_success_terminal` 为真且 `_success_frames >= success_hold_frames` 时 `_end_episode(reward_success)` |

**为什么 `_success_frames` 要由 `_do_dropoff` 直接置满**：原实现里
`_success_frames` 声明了但从不递增，`_is_success` 永远是 `false`，
导致 Python 侧的成功率统计恒为 0。送达是一个**离散的瞬时事件**
（不是需要持续满足的连续条件），所以直接置位是正确语义。

### 1.2 `vehicle/AI/sync_taxi.gd`（**新增，不改插件本体**）

插件 `addons/godot_rl_agents/sync.gd` **不做任何修改**；所有定制放在子类里。

| 改动 | 说明 |
|---|---|
| 新增 `vehicle/AI/sync_taxi.gd`（`extends Sync`，`class_name TaxiSync`） | 在 `super._ready()` 之前等车队生成完成 |
| 新增 `@export var vehicle_spawn_manager: VehicleSpawnManager` | **必须在检视器里拖引用**（唯一查找方式，不依赖分组） |
| 新增 `@export var fleet_ready_timeout: float = 8.0` | 等待超时，兜底避免永久挂住 |
| `_wait_for_fleet()` | 见下面的等待逻辑 |
| `_report_agent_state()` | 初始化后检查 agent 列表，为空时给出明确诊断 |

**为什么需要它（问题根因）**：

`VehicleSpawnManager` 用 `call_deferred("_spawn_fleet")` 生成车队，即车辆在**当前帧
idle 处理末尾**才被实例化。而 `Sync._ready()` 的流程是：

```gdscript
await get_parent().ready      # 只保证 VehicleSpawnManager._ready 跑过、deferred 已排队
get_tree().set_pause(true)
_initialize()
    └─ _get_agents()          # ← 此刻车还不存在 → 空数组
        └─ _initialize_training_agents()
            └─ if agents_training.size() > 0:   # 不成立
                   connect_to_server()          # 根本不连接
```

结果：Godot 不暂停、不等 Python，训练侧一直卡在
`waiting for remote GODOT connection on port 11008`。

**解法（方向 C2 + 兜底）**：子类在调用 `super._ready()` 之前先等 `fleet_ready` 信号。

**生成器引用方式：`@export` 节点引用，不用分组。**
（早期版本用 `get_first_node_in_group("vehicle_spawn_manager")` 查找，但那依赖
管理器的 `_ready()` 执行时机——`TaxiSync._ready()` 可能比它更早跑到，
结果查不到管理器、跳过等待，于是 `AGENT` 组仍为空。已改为直接 `@export` 引用。）

兜底逻辑：

| 兜底 | 条件 | 行为 |
|---|---|---|
| 1 | `vehicle_spawn_manager` 未设置 | `push_warning` 提示拖引用，不等待 |
| 2 | `auto_spawn == false`（车静态摆放） | 直接继续（不会有人 emit） |
| 3 | 管理器没有 `fleet_ready` 信号 | 告警后继续 |
| 4 | `vehicles` 已非空（信号早于 await 发出） | 直接继续（避免错过信号死等） |
| 5 | 以上都不成立 | `await fleet_ready`，带 `fleet_ready_timeout` 超时兜底 |

**已知边界**：本方案只修"首次握手"的时序，**不修**"回合重置后车辆重建"的问题——
`VehicleSpawnManager.reset()` 会销毁旧车并生成新车，新实例不在
`Sync.agents_training` 里，而 `_get_agents()` 全项目只在 `_initialize()` 调一次。
**前提是：握手时车已就位，且训练期间不增删车辆。**

### 1.3 `vehicle/VehicleSpawnManager.gd`

| 改动 | 说明 |
|---|---|
| 新增 `signal fleet_ready` | `_spawn_fleet()` 结束时 emit（含异常路径），供 `TaxiSync` 等待 |
| `_ready()` 加入组 `rl_stats_providers` | 让 sync 的 call 广播能到达 |
| 新增 `get_env_stats() -> Dictionary` | `vehicles_alive` / `companies` / `free_spawners` |
| 新增 `_find_controller(node) -> AITaxiController` | `company_id` 写在车内控制器上，统计时需要向下找 |

### 1.4 `addons/godot_rl_agents/sync.gd`

> ⚠️ **这是插件文件。** 时序修复（方向 C2）**不需要改它**——那个通过
> `vehicle/AI/sync_taxi.gd` 子类实现。这里的两处改动是为 `get_env_stats`
> 和 reset 时序做的，如果以后升级插件需要重新打补丁。

| 改动 | 说明 |
|---|---|
| `_call_method_on_agents(method)` | 除 `AGENT` 组外，额外广播给组 `rl_stats_providers` |
| `_reset_agents()` | 置 `needs_reset` 后**立即**调用 `agent._reset_episode()` |
| `handle_message()` 的 print | 补上方法名，便于排查（无功能影响） |

**为什么要把 `rl_stats_providers` 纳入广播**：godot_rl 原协议的 `call`
只遍历 `AGENT` 组，而 `get_env_stats()` 需要问 `PassengerManager` /
`VehicleSpawnManager` 要全局数字。它们不是 agent，收不到消息。

**为什么 `_reset_agents` 要立即执行重置**：原实现只置 `needs_reset = true`，
真正的重置要等下一物理帧。但 `_training_process` 会先把**当前（重置前）**的观测
发回 Python，导致首个观测与实际状态不一致。

> 注：本项目 `addons/godot_rl_agents/sync.gd` 相对插件原始版本还有大量
> **注释中文化**（项目作者早先做的），那些不属于本次改动。

### 1.5 `Passenger/PassengerManager.gd`

| 改动 | 说明 |
|---|---|
| `_ready()` 加入组 `rl_stats_providers` | 让 sync 的 call 广播能到达 |
| 新增 `get_env_stats() -> Dictionary` | `passengers_alive` / `passengers_waiting` / `current_number` / `free_spawners` / `max_number` |

### 1.6 已移除的改动（重要）

早期版本曾在 GDScript 侧加过"训练中下发课程参数"的机制，**已全部移除**，
因为课程阶段改为离线人工切换：

- ~~`AITaxiController.apply_curriculum_params()` / `_apply_params_recursive()`~~
- ~~`sync.gd` 的带参 `call`（`_call_method_on_agents_with_args`）~~
- ~~`PassengerManager.apply_curriculum_params()`~~
- ~~`VehicleSpawnManager.apply_curriculum_params()` / `_respawn_fleet()`~~

现在 `sync.gd` 的 `call` 分支与原版一致（只带 `method`），Godot 侧不需要任何
协议扩展。阶段参数请在编辑器里配置，见 `rl/docs/CURRICULUM.md`。

---

## 2. 还需要你手工做的

### 2.1 给 `TrainScene.tscn` 加 Sync 节点（**阻塞项**）

当前 `TrainScene.tscn` **没有 `Sync` 节点**，Python 无法连接。

1. 打开 `levels/TrainScene.tscn`；
2. 在根节点 `TrainScene` 下新建 `Node`，命名 `Sync`（或任意名）；
3. 挂脚本 **`res://vehicle/AI/sync_taxi.gd`**（不是 `sync.gd`！）；
4. 检视器设置：
   - `control_mode` = `TRAINING`
   - `action_repeat` = `8`
   - `speed_up` = `1`
   - **`vehicle_spawn_manager` = 把场景里的 `VehicleSpawnManager` 节点拖进来**（关键）
   - `fleet_ready_timeout` = `8.0`

> **`vehicle_spawn_manager` 必须拖引用**：这是 `TaxiSync` 找生成器的唯一方式。
> 留空会打印 `vehicle_spawn_manager 未设置！` 并跳过等待，于是 `AGENT` 组为空、
> 连不上 Python。
>
> 早期版本用分组 `vehicle_spawn_manager` 查找，但那只在管理器 `_ready()` 之后才有效，
> 而 `TaxiSync._ready()` 可能更早跑到——这是踩过的坑，已改为 `@export` 引用。

> **为什么挂子类而不是 `sync.gd`**：`VehicleSpawnManager` 用 `call_deferred` 生成车队，
> 而 `Sync._ready()` 在车生成之前就扫了 `AGENT` 组，拿到空数组后直接跳过连接
> （详见 §1.2）。`TaxiSync` 在 `super._ready()` 之前等 `fleet_ready` 信号，
> 修掉这个时序问题，且不改插件本体。

**验证握手是否成功**：启动训练后看 Godot 输出面板，应出现：

```
[TaxiSync] 等待车队生成（fleet_ready）…
[TaxiSync] 车队已生成，继续初始化。
[TaxiSync] 已登记 agent：all=N, training=N     ← N 必须 > 0
performing handshake
handshake complete
```

如果看到 `agents_training 为空，Sync 不会连接 Python！`，按 `push_error` 里的
三条原因逐项排查。

### 2.2 按阶段配置场景

阶段参数表见 `rl/docs/CURRICULUM.md`，分两处落地：

- `AIParameter` 面板 → 点「一键同步到所有AI节点」
- 场景管理器 → 手改 `VehicleSpawnManager.faction_list` / `vehicles_per_faction`、
  `PassengerManager.max_number` / `moving_probability`

### 2.3 S0 阶段建议先关掉 `isMovingRewardFunction`

它惩罚连续低速，但接客/送达**必须停稳**，两者直接冲突。
S0 先在 `RewardManager` 下禁用它，确认策略能学会接客后，S1 再加回来
（配合 `grace_steps` 放宽到 480~600 步）。

### 2.4 观测缺口（可选，但建议在正式训练前定稿）

| 缺口 | 建议补的观测 |
|---|---|
| 没有"自车朝向 vs 目标方向"的显式夹角 | 2 维 `[cos θ, sin θ]` |
| 载客时无法区分"空车找客"和"载客送客" | 2 维 `[has_passenger, 是否已接未送达]` |
| 对手只有相对位置，没有相对速度/朝向 | 每个对手 +2 维 |

**必须一次性补齐并固定**：godot_rl 的观测空间在握手时确定，训练中途改维度
会让 SB3 直接报 shape 错误。补完之后要同步更新
`rl/feature_extractors.py` 里的 `SELF_STATE_DIM` / `raycast_dim`。

---

## 3. 验证状态（诚实记录）

| 项目 | 状态 |
|---|---|
| Python 侧（`rl/`） | ✅ 全部通过 `python rl/selftest.py`（7 项，只测网络形状） |
| Python 语法 | ✅ 全部通过 `py_compile` |
| GDScript 语法 | ⚠️ **需你重启编辑器确认** |

### 已修复的真实错误

| 错误 | 现象 | 修复 |
|---|---|---|
| `Identifier "reward_dropoff" not declared` | `AITaxiContorller.gd:311` 解析失败，整个控制器无法加载 | `reward_dropoff` 在 `PickUpAndDropRewardFunction` 上，控制器里没有 → 改用新增的 `reward_success` |
| `func _physics_process(delta):` 签名丢失 | 函数体变成顶层代码，4 处 `return` 报 `Cannot return value of type "null"` | 补回函数签名 |
| lambda 内修改捕获变量 | GDScript 4 不允许 `func(n): applied += n` | 改为返回值累加 |

### 为什么 GDScript 无法在这里完成验证

编辑器持有脚本缓存，`ResourceLoader.load(..., CACHE_MODE_REPLACE)` 仍返回
改动前的版本（已知的 Godot 编辑器行为）。已验证的替代手段：
用**无 BOM、唯一 class_name** 的副本文件加载（BOM 会让 GDScript 解析失败，
这是踩过的坑）。

| 文件 | 验证结果 |
|---|---|
| `vehicle/AI/sync_taxi.gd` | ✅ 40 methods，基类正确解析为 `addons/godot_rl_agents/sync.gd` |
| `vehicle/VehicleSpawnManager.gd` | ✅ 11 methods，`fleet_ready` 信号存在 |
| `vehicle/AI/AITaxiContorller.gd` | ✅ 41 methods（`_physics_process` 修复后） |
| `addons/godot_rl_agents/sync.gd` | ✅ 36 methods |
| `Passenger/PassengerManager.gd` | ⚠️ 重命名 class 会触发类型引用错误（副本的伪错误），此法无法验证 |

**请重启 Godot 编辑器**，然后启动一次短训练验证链路：

```bash
python rl/train.py --viz --timesteps 2000 --experiment_name smoke
```

训练启动时会打印观测空间、动作空间和分塔维度。确认这三项都正常、
且 TensorBoard 里能看到 `task/dropoffs` 等指标，就说明 Godot 侧全部就绪。
这一步通过就说明 Godot 侧全部就绪。
