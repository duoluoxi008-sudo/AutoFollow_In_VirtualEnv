# 训练运行手册

## 0. 前提：Godot 侧必须先配好

### 0.1 TrainScene 缺少 Sync 节点（**当前阻塞项**）

`levels/TrainScene.tscn` 里目前**没有 `Sync` 节点**，而 `Sync` 是 godot_rl 的通信中枢——
没有它，Python 连不上，训练无法开始。需要手动加：

1. 在 `TrainScene.tscn` 根节点下新建一个 `Node`，命名 `Sync`；
2. 给它挂脚本 **`res://vehicle/AI/sync_taxi.gd`**（`Sync` 的子类，不是 `sync.gd`）；
3. 检视器里设置：
   - `control_mode` = `TRAINING`（子节点继承这个模式）
   - `action_repeat` = `8`（建议先用 8，与 `AIController3D` 默认一致）
   - `speed_up` = `1`（编辑器内训练时加速无效，用 `--speedup` 控制导出后的实例）
   - **`vehicle_spawn_manager` = 把 `VehicleSpawnManager` 节点拖进来**（关键，别漏）
   - `fleet_ready_timeout` = `8.0`

> **为什么必须挂 `sync_taxi.gd`**：`VehicleSpawnManager` 用 `call_deferred` 生成车队，
> 而原版 `Sync._ready()` 在车生成**之前**就扫 `AGENT` 组 → 拿到空数组 →
> 直接跳过连接，表现为"Godot 不暂停、Python 一直等"。`TaxiSync` 在初始化前
> 等 `fleet_ready` 信号，修掉这个时序问题。
>
> **`vehicle_spawn_manager` 是必需引用**：`TaxiSync` 用它找到生成器并 `await` 它的信号。
> 留空会告警并跳过等待，等于没修。详见 `rl/docs/GODOT_SIDE_CHANGES.md` §1.2。

**握手成功的标志**（Godot 输出面板）：

```
[TaxiSync] 等待车队生成（fleet_ready）…
[TaxiSync] 车队已生成，继续初始化。
[TaxiSync] 已登记 agent：all=N, training=N
performing handshake
handshake complete
```

### 0.2 AITaxiController 的控制模式

`vehicle/AI/mmt_ai_sedan.tscn` 里的 `AITaxiController` 默认 `control_mode = INHERIT_FROM_SYNC`，
会继承 `Sync` 的 `TRAINING`，**不需要单独改**。

### 0.3 安装 Python 依赖（uv）

项目已用 **uv** 管好环境，`pyproject.toml` + `uv.lock` + `.venv` 都在项目根目录。

```bash
# 一次性：按 lock 文件创建/同步 .venv（含 godot-rl 本地依赖）
uv sync

# 跑训练（uv run 会自动确保环境是最新的）
uv run python rl/train.py --viz --experiment_name taxi_S0
```

**不需要手动 `activate`**：`uv run` 会自动使用 `.venv`。

#### 依赖是怎么配的

| 依赖 | 来源 |
|---|---|
| `stable-baselines3` / `gymnasium` / `numpy` / `torch` / `tensorboard` / `pyyaml` | PyPI |
| `godot-rl` | **本地 path 依赖**，vendored 在 `rl/godot_rl/` |

`pyproject.toml` 里的关键是：

```toml
dependencies = ["godot-rl", ...]

[tool.uv.sources]
godot-rl = { path = "rl/godot_rl", editable = true }
```

**为什么把 `godot_rl` vendor 进项目**：原始参考实现在
`E:\Godot\local plugin\godot_rl_agents-0.8.2`，直接 `uv add --editable <该路径>`
会因为 setuptools 要往该目录写 `egg-info` 而失败（目录权限/在项目外）。
拷一份 61 KB 的源码进项目后，uv 能正常构建安装，且不依赖外部路径。
改动 `rl/godot_rl/` 里的代码会立即生效（editable）；要同步参考实现的更新，
重新拷一次 `godot_rl/` 目录即可。

#### `uv.toml` 里的 `cache-dir`

```toml
cache-dir = ".uv-cache"
```

默认缓存目录是 `%LOCALAPPDATA%\uv\cache`。某些环境（受限账户 / 沙箱 / 企业策略）
对它没有写权限，uv 会直接报：

```
error: Failed to initialize cache at `C:\Users\<you>\AppData\Local\uv\cache`
  Caused by: failed to open file ...: 拒绝访问。 (os error 5)
```

指到项目内即可绕开。`.uv-cache/` 和 `.venv/` 已在 `.gitignore` 里忽略。

#### 可选：ONNX 导出

`onnx` / `onnxruntime` **没有**装进默认依赖，因为 `onnxruntime` 目前只提供
cp310+ 的 wheel，而本项目跑在 **CPython 3.9**：

```
error: Distribution `onnxruntime==1.20.1` ... doesn't have a source distribution
or wheel for the current platform (only has cp310, cp311, cp312, cp313)
```

需要导出 ONNX 时，二选一：

```bash
# 方案 A：升级到 Python 3.10+，然后
uv python pin 3.11 && uv sync && uv add onnx onnxruntime

# 方案 B：留在 3.9，跳过 ONNX（训练和评估都不受影响）
```

#### 不用 uv 的话

也可以直接用系统 Python，但要自己装依赖：

```bash
pip install stable-baselines3 gymnasium "numpy<2" tensorboard pyyaml torch
pip install -e "E:\Godot\local plugin\godot_rl_agents-0.8.2"   # 可能需要管理员权限
```

### 0.4 按阶段配置场景

阶段参数见 `rl/docs/CURRICULUM.md` 的表格，分两处落地：

- `AIParameter` 面板 → 点「一键同步到所有AI节点」
- `VehicleSpawnManager` / `PassengerManager` → 手改导出值

---

## 1. 三种运行方式

### 1.1 编辑器内训练（推荐先用这个）

在编辑器里打开 `TrainScene.tscn`，**不要按 PLAY**，先在终端运行：

```bash
uv run python rl/train.py --viz --experiment_name taxi_S0
```

终端会打印 `waiting for remote GODOT connection on port 11008`，此时再在编辑器里按 PLAY。

> `--viz` 在编辑器内训练时无效（编辑器总是渲染），加上只是为了统一命令。

### 1.2 只推理（看策略行为，不训练）

```bash
uv run python rl/train.py --inference --resume_model_path rl/logs/taxi_S0.zip --viz
```

### 1.3 并行无头训练（正式训练）

先导出 Godot 项目，然后：

```bash
uv run python rl/train.py --env_path build/AutoFollow.exe --n_parallel 8 \
                   --experiment_name taxi_S4 --timesteps 20000000
```

- `n_parallel` 个实例各占一个端口（`11008 + p`）；
- 每个实例独立从场景里的生成点生成车队/乘客；
- **CPU 是瓶颈**（物理仿真），一般 `n_parallel` = 物理核心数；
- `--speedup 4` 可以加速物理，但太高会让车辆物理失真，建议 ≤ 4。

---

## 2. TensorBoard 看什么

```bash
tensorboard --logdir rl/logs
```

日志按 `--experiment_name` 分目录，所以每个阶段一个目录，方便对比。

### 2.1 最该看的四条曲线（按优先级）

| 曲线 | 含义 | 健康表现 |
|---|---|---|
| `task/dropoffs` | **累计送达数** | 单调上升。这是唯一能证明"策略在真的接客"的指标 |
| `task/success_rate` | 最近 200 回合成功率 | 稳步上升到该阶段目标 |
| `task/episode_length` | 平均回合长度 | 下降（送达变快）。若一直贴着 `reset_after`，说明从没成功过 |
| `task/stolen` | 累计被抢客次数 | S3+ 才看；持续飙升说明策略在"跟着对手跑" |

### 2.2 为什么不能只看 `rollout/ep_rew_mean`

因为奖励里有**势函数塑形**（`shaping_scale × 距离减少量`）。策略可以靠"来回晃悠"
刷塑形奖励，一次客都不接。**`ep_rew_mean` 高但 `task/dropoffs` 为 0 是最常见的陷阱。**

### 2.3 其余曲线

| 曲线 | 含义 |
|---|---|
| `task/pickups` | 累计接客数 |
| `task/episode_reward` | 最近 200 回合平均奖励 |
| `train/entropy_loss` | 策略熵。快速塌到 0 → `ent_coef` 太小 |
| `train/approx_kl` | 应保持在 0.01~0.02 附近；>0.05 说明更新步子太大 |
| `train/clip_fraction` | 若接近 1.0，说明 `clip_range` 太小或 lr 太大 |

---

## 3. 课程阶段怎么工作

**阶段是离线切换的**，Python 侧不认识"阶段"：

```
你决定进入下一阶段
  → 看 rl/docs/CURRICULUM.md 的参数表
  → 在 Godot 编辑器里改 AIParameter / 场景管理器
  → uv run python rl/train.py --experiment_name taxi_S1 [--resume_model_path ...]
  → 看 TensorBoard，确认达标
  → 回到第一步
```

`--experiment_name` 只影响 TensorBoard 目录名和检查点文件名，**不改变环境难度**。

---

## 4. 故障排查

### 4.1 连不上

| 现象 | 原因 | 处理 |
|---|---|---|
| `waiting for remote GODOT connection on port 11008` 一直不结束 | 没按 PLAY / 场景里没有 Sync 节点 / **挂的是 `sync.gd` 而不是 `sync_taxi.gd`** | 检查 §0.1；确认 Play 的是 `TrainScene.tscn` 而不是主菜单 |
| Godot 里看到 `agents_training 为空，Sync 不会连接 Python！` | 扫 `AGENT` 组时车还没生成（时序问题） | 必须挂 `sync_taxi.gd`；再检查 `VehicleSpawnManager.auto_spawn` / `car_scene` / 生成点数量 |
| Godot 里看到 `等待 fleet_ready 超时` | `VehicleSpawnManager` 没有真的生成车辆 | 看它自己的 `push_warning`（`car_scene 未设置` / `没有空闲的 VehicleSpawner`） |
| `Couldn't connect to Python server, using human controls instead` | 先启动了 Godot，再启动 Python（顺序反了） | 必须先启动 Python 脚本，再按 PLAY |
| `env timed out` | Godot 卡住或已退出 | 看 Godot 输出面板；确认没有物理报错 |
| `ModuleNotFoundError: No module named 'godot_rl'` | 没装依赖 | 见 §0.3 |
| 端口占用 | 上次进程没退干净 | 换 `port`（在 `godot_rl` 的 `GodotEnv` 里），或杀掉残留进程 |

### 4.2 观测/动作相关

| 现象 | 原因 | 处理 |
|---|---|---|
| SB3 报 shape 不匹配 | 观测长度和训练时不一致 | 确认各阶段的 `max_opponents_obs` 相同 |
| `各 agent 观测形状不一致` | 某个 agent 的传感器没配全 | 检查 `mmt_ai_sedan.tscn` 的 `Rl/Sensor` 子树 |
| 动作维度不对 | godot_rl 把 3 键 Dict 动作空间压成 `Box(3)` | 正常。顺序 = throttle/steering/brake |
| 训练启动时打印的分塔维度不对 | `--raycast_dim` 和场景里的传感器配置不匹配 | 改了 `RayCastSensor3D` 的网格/数量后，同步改 `--raycast_dim` |

### 4.3 训练不动（最重要的一类）

| 现象 | 诊断 | 处理 |
|---|---|---|
| 车辆数量不对 | 车队生成失败 | 检查 `VehicleSpawnManager.car_scene`、`faction_list`、生成点数量 |
| 场上没有可接的乘客 | 乘客生成不出来 | 检查 `PassengerManager.max_number`、生成点数量、`spawn_interval` |
| 有乘客但 `task/dropoffs` = 0 | 策略问题：学不会停靠 | 见 4.4 |
| `ep_rew_mean` 涨但 `task/dropoffs` = 0 | **塑形奖励被刷** | 降低 `shaping_scale`，提高 `reward_dropoff`，或提高 `step_cost` |
| `task/episode_length` 一直贴着 `reset_after` | 从没成功过（回合靠超时结束） | 确认 `enable_success_terminal` 在检视器里勾上了 |

### 4.4 车辆不开 / 原地转圈 / 不会停

| 现象 | 原因 | 处理 |
|---|---|---|
| 车辆不动 | 低速惩罚过重，或 `step_cost` 过大 | S0 阶段先禁用 `isMovingRewardFunction`，确认能学会接客再加回来 |
| 一直高速冲过乘客 | `pickup_radius` 太小 / `stop_speed_threshold` 太严 | 放宽到 `pickup_radius=3.0`、`stop_speed_threshold=2.0` 试 |
| 接客后原地转圈不去目的地 | `PassengerPositionSensor3D` 没切到目的地 | 检查 `carried_passenger.destination` 是否非空；看 `_resolve_target()` |
| 车辆翻车/卡墙 | 射线避障不够 / 奖励没惩罚碰撞 | 提高 `FarSight` 射线长度，或加碰撞惩罚奖励函数 |

### 4.5 竞争阶段（S3+）专门问题

| 现象 | 原因 | 处理 |
|---|---|---|
| `task/stolen` 飙升但 `dropoffs` 不涨 | 策略学会"跟着对手跑"而不是"自己去接客" | 提高 `stolen_penalty`，或降低 `max_opponents_obs` 让它少看对手 |
| 所有车挤在同一个乘客旁 | 同公司协作失效 / 跨公司争抢 | 检查 `PassengerDistributeManager.cooperative_within_fleet`；竞争阶段这是**正常现象**，但要确认最终有人接到 |
| 成功率突然从 55% 掉到 20% | 阶段切换的正常跳变 | 看切换后**至少一个完整 rollout**（`n_steps × num_envs` 步）的 `task/success_rate` 再判断 |

---

## 5. 保存、续训与导出

```bash
# 训练中定期存检查点
uv run python rl/train.py --viz --save_checkpoint_frequency 200000 --experiment_name taxi_S0

# 训练结束保存模型
uv run python rl/train.py --viz --save_model_path rl/logs/taxi_S0

# 续训
uv run python rl/train.py --viz --resume_model_path rl/logs/taxi_S0.zip --experiment_name taxi_S1

# 导出 ONNX（给 Godot 的 ONNX_INFERENCE 模式用）
uv run python rl/train.py --resume_model_path rl/logs/taxi_S0.zip \
                   --onnx_export_path rl/models/taxi.onnx --timesteps 1
```

> `--save_checkpoint_frequency` 的目录已存在时会覆盖检查点；换阶段请换
> `--experiment_name`，否则新旧检查点混在一起。

---

## 6. 建议的调试顺序

```
① 装好 godot_rl，给 TrainScene 加 Sync 节点
      ↓
② uv run python rl/selftest.py            # 3 秒验证网络形状（不连 Godot）
      ↓
③ uv run python rl/train.py --viz --inference --resume_model_path <任意模型>   # 或直接小步数训练
      ↓
④ S0 正式训练，确认 task/dropoffs 上升
      ↓
⑤ 评估：uv run python rl/evaluate.py --model rl/logs/taxi_S0.zip --viz --episodes 20
      ↓
⑥ 改场景进入 S1，--resume_model_path 继续训练
      ↓
⑦ 可视化录像人工确认"车真的在开"
```

**每一步不通过就不要进入下一步**，否则问题会叠加，无法归因。
